package com.us.senate.vote.model;

public class Vote {

	private String preference;
	private String role;
	private int votersId;

	public String getPreference() {
		return preference;
	}

	public void setPreference(String preference) {
		this.preference = preference;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getVotersId() {
		return votersId;
	}

	public void setVotersId(int votersId) {
		this.votersId = votersId;
	}

}
