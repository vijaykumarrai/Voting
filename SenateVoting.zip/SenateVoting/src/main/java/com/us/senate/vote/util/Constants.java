/**
 * 
 */
package com.us.senate.vote.util;

/**
 * @author Vijay2.Rai
 *
 */
public class Constants {
	public static String TIE="TIE";
	public static String TOTAL_GREATER_THAN_100="Maximum vote can be total 101";
	public static String ROLE_VP="VP";
	public static String VP_CANT_VOTE="VP can vote only if the motion is a tie";
	public static String POLL_NOT_STARTED="Poll is not yet opened";
	public static String PASSED="Passed";
	public static String FAILED="Failed";
	public static String ONLY_VP_CAN_VOTE="Poll is a tie.Only VP can vote.";
	public static String CAN_VOTE_ONLY_ONCE="A member can vote only once";
	public static String NO_POLL_EXISTS="No poll exists";
	public static String NOT_STARTED="Poll not started";
	public static String INVALID_POLL="Invalid poll";
	public static String SUCCESS="success";
	public static String YES="YES";
	public static String DISPLAY_VOTE="Voted as ";
	public static String INVALID_VOTE= "Invalid vote";
	public static String STATUS_NOT_TIE="Poll is not in a tied state";
	public static long MINS_15=15 * 60 * 1000;

}
