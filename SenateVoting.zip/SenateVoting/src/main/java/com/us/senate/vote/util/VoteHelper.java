package com.us.senate.vote.util;

import java.util.Calendar;
import java.util.Date;

import com.us.senate.vote.handler.VoteHandler;
import com.us.senate.vote.model.PollingData;
import com.us.senate.vote.model.Vote;

public class VoteHelper {

	public static boolean checkAlreadyVoted(Vote vote) {
		boolean result = false;
		if (VoteHandler.votes.contains(vote.getVotersId())) {
			System.out.println(Constants.CAN_VOTE_ONLY_ONCE);
			result = true;
		}
		return result;
	}

	public static String processVote(PollingData pollData, Vote vote) {
		String response = "";
		if (Constants.TIE.equals(pollData.getStatus())) {
			response = handleTie(vote);
		} else if (pollData.getTotalCount() > 100) {
			response = Constants.TOTAL_GREATER_THAN_100;
		} else if (Constants.ROLE_VP.equals(vote.getRole())) {
			response = Constants.VP_CANT_VOTE;
		} else {
			response = calculateVote(vote.getVotersId(), vote.getPreference(), pollData);
		}
		return response;
	}

	public static String handleTie(Vote vote) {
		String result;
		if (Constants.ROLE_VP.equals(vote.getRole())) {
			result = calculateVote(vote.getVotersId(), vote.getPreference(), VoteHandler.pollData);
			VoteHandler.pollData.setClosed(true);
			VoteHandler.pollData
					.setStatus(VoteHandler.pollData.getYesCount() > VoteHandler.pollData.getNoCount() ? Constants.PASSED
							: Constants.FAILED);
			VoteHandler.pollData.setEndTime(new Date());
		} else {
			result = Constants.ONLY_VP_CAN_VOTE;
		}
		return result;
	}

	public static String calculateVote(int voterId, String answer, PollingData data) {
		String result = Constants.SUCCESS;
		if (Constants.YES.equalsIgnoreCase(answer)) {
			data.setYesCount(data.getYesCount() + 1);
			data.setTotalCount(data.getTotalCount() + 1);
			VoteHandler.votes.add(voterId);
			result = Constants.DISPLAY_VOTE + answer;
		} else if ("NO".equalsIgnoreCase(answer)) {
			data.setNoCount(data.getNoCount() + 1);
			data.setTotalCount(data.getTotalCount() + 1);
			VoteHandler.votes.add(voterId);
			result = Constants.DISPLAY_VOTE + answer;
		} else {
			result = Constants.INVALID_VOTE;
		}
		return result;
	}

	public static boolean pollStartedBefore15Mins(Date date) {
		Calendar previous = Calendar.getInstance();
		previous.setTime(date);
		return ((Calendar.getInstance().getTimeInMillis() - previous.getTimeInMillis()) > Constants.MINS_15);
	}

}
