package com.us.senate.vote.handler;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.us.senate.vote.model.PollingData;
import com.us.senate.vote.model.Vote;
import com.us.senate.vote.util.Constants;
import com.us.senate.vote.util.VoteHelper;

public class VoteHandler {
	public static PollingData pollData;
	public static Set<Integer> votes = new HashSet<>();

	/**
	 * handle members votes.
	 * 
	 * @param vote
	 * @return String
	 */
	public String handle(Vote vote) {
		String response = "";
		/* one user can vote only once. */
		if (VoteHelper.checkAlreadyVoted(vote)) {
			return response;
		}
		if (pollData != null) {
			if (pollData.isOpened() && !pollData.isClosed()) {
				response = VoteHelper.processVote(pollData, vote);
			} else {
				response = Constants.POLL_NOT_STARTED;
			}
		} else {
			response = Constants.POLL_NOT_STARTED;
		}
		return response;
	}

	/**
	 * start the poll
	 */
	public void startPoll() {
		if (pollData == null) {
			pollData = new PollingData();
		}
		pollData.setOpened(true);
		pollData.setStartTime(new Date());
	}

	/**
	 * close the poll
	 * 
	 * @return String
	 */
	public String closePoll() {
		String result = "";
		if (pollData == null) {
			result = Constants.NO_POLL_EXISTS;
		} else {
			if (!pollData.isOpened()) {
				result = Constants.NOT_STARTED;
			}/* else if (!VoteHelper.pollStartedBefore15Mins(pollData.getStartTime())) {
				result = "Poll cannot be closed before 15 mins after starting";
			}*/ else if (pollData.getYesCount() == pollData.getNoCount()) {
				pollData.setStatus(Constants.TIE);
				result = Constants.TIE;
			} else {
				pollData.setClosed(true);
				pollData.setEndTime(new Date());
				pollData.setStatus(
						pollData.getYesCount() > pollData.getNoCount() ? Constants.PASSED : Constants.FAILED);
				result = pollData.toString();
				//System.out.println(pollData.toString());
			}
		}

		if (!"".equals(result))
			System.out.println(result);

		return result;
	}

	/**
	 * forcibly close the poll
	 * 
	 * @return String
	 */
	public String forceClose() {
		String result = "";
		if (pollData == null) {
			result = Constants.INVALID_POLL;
		} else {
			if (!pollData.getStatus().equals(Constants.TIE)) {
				result = Constants.STATUS_NOT_TIE;
			} else {
				pollData.setClosed(true);
				pollData.setEndTime(new Date());
				pollData.setStatus(Constants.FAILED);
				result = pollData.toString();
			}
		}
		return result;
	}

	public static String getPollStatus() {
		String result = "";

		if (pollData != null)
			result = pollData.toString();
		System.out.println(result);
		return result;
	}

	public static PollingData getPollData() {
		return pollData;
	}

	public static void setPollData(PollingData data) {
		VoteHandler.pollData = data;
	}

	public static Set<Integer> getVotes() {
		return votes;
	}

	public static void setVotes(Set<Integer> votes) {
		VoteHandler.votes = votes;
	}

}