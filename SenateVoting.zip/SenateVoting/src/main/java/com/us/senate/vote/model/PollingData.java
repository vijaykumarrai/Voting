package com.us.senate.vote.model;

import java.util.Date;

public class PollingData {
	private Date startTime;
	private Date closeTime;
	private int totalVotes;
	private boolean opened;
	private boolean closed;
	private int yeas;
	private int noes;
	private String status = "In moving";

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return closeTime;
	}

	public void setEndTime(Date endTime) {
		this.closeTime = endTime;
	}

	public int getTotalCount() {
		return totalVotes;
	}

	public void setTotalCount(int totalCount) {
		this.totalVotes = totalCount;
	}

	public boolean isOpened() {
		return opened;
	}

	public void setOpened(boolean opened) {
		this.opened = opened;
	}

	public boolean isClosed() {
		return closed;
	}

	public void setClosed(boolean closed) {
		this.closed = closed;
	}

	public int getYesCount() {
		return yeas;
	}

	public void setYesCount(int yesCount) {
		this.yeas = yesCount;
	}

	public int getNoCount() {
		return noes;
	}

	public void setNoCount(int noCount) {
		this.noes = noCount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Senate poll status ");
		builder.append(status + "\n");
		builder.append("Total yeas : " + yeas + " and noes : " + noes + "\n");
		builder.append("started at " + startTime + "\n");
		builder.append("" + ((closeTime != null) ? (" and closed at " + closeTime) : "") + "\n");
		return builder.toString();

	}
}
