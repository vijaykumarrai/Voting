package com.us.senate.vote.handler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;

import org.junit.Test;

import com.us.senate.vote.model.PollingData;
import com.us.senate.vote.model.Vote;

public class VoteHandlerTest {

	VoteHandler service = new VoteHandler();

	@Test
	public void test_yes() {
		System.out.println("## Testcase1 : Vote Yes ##\n");
		service.setPollData(new PollingData());
		service.getVotes().remove(1);
		service.startPoll();
		String result = service.handle(getVote(1, "YES"));
		System.out.println(result);
		assertEquals(1, service.getPollData().getYesCount());
		System.out.println("####\n\n");
	}

	@Test
	public void test_no() {
		System.out.println("## Testcase2 : Vote No ##\n");
		service.setPollData(new PollingData());
		service.getVotes().remove(2);
		service.startPoll();
		String result = service.handle(getVote(2, "NO"));
		System.out.println(result);
		assertEquals(1, service.getPollData().getNoCount());
		System.out.println("####\n\n");
	}

	@Test
	public void test_poll_not_opened() {
		System.out.println("## Testcase3 :  No voting till opened ##");
		service.setPollData(new PollingData());
		service.votes.remove(6);
		String result = service.handle(getVote(6, "YES"));
		System.out.println(result);
		System.out.println("####\n\n");
	}

	@Test
	public void test_close() {
		System.out.println("## Testcase4 :  close the poll ##");
		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		service.handle(getVote(7, "YES"));
		service.closePoll();
		System.out.println("####\n\n");
	}

	@Test
	public void test_close_before_15_mins() {
		System.out.println("## Testcase5 :  try to close before 15 mins ## \n code commented at line 60+ in source so that other cases can be tested.\nPLEASE UNCOMMENT THOSE 3 LINES TO TEST THIS.\n\n");
		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		service.handle(getVote(20, "NO"));
		service.closePoll();
		System.out.println("####\n\n");
	}

	@Test
	public void test_multiple_vote() {
		System.out.println("## Testcase6 :  cant vote twice with same voterId ##");
		service.setPollData(new PollingData());
		service.startPoll();
		service.handle(getVote(59, "YES"));
		String result = service.handle(getVote(59, "NO"));
		System.out.println(result + "\n");
		System.out.println("####\n\n");
	}

	@Test
	public void test_max_101() {
		System.out.println("## Testcase7 :  Maximum vote 101 ##");
		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		for (int i = 1; i <= 101; i++)
			service.handle(getVote(i, "YES"));
		String result = service.handle(getVote(102, "NO"));

		System.out.println(result);
		System.out.println("####\n\n");

	}

	@Test
	public void test_close_when_tie() {
		System.out.println("## Testcase8 :  Move to TIE state while closing ##");
		service.startPoll();
		for (int i = 1; i <= 10; i++) {
			service.handle(getVote(i, "YES"));
		}
		for (int i = 11; i <= 20; i++) {
			service.handle(getVote(i, "NO"));
		}

		String result = service.closePoll();
		System.out.println("Status : " + result);
		System.out.println("####\n\n");
	}

	@Test
	public void test_only_vp_allowed_to_vote() {
		System.out.println("## Testcase 9 :  Only VP allowed to vote during TIES ##");

		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		for (int i = 1; i <= 10; i++) {
			service.handle(getVote(i, "YES"));
		}
		for (int i = 11; i <= 20; i++) {
			service.handle(getVote(i, "NO"));
		}

		String result = service.closePoll();
		System.out.println(result);

		String handleResult = service.handle(getVote(22, "NO"));
		System.out.println(handleResult);
		System.out.println("####\n\n");

	}

	@Test
	public void test_vp_cant_vote_if_poll_not_tie() {
		System.out.println("## Testcase 10 :  VP not allowed to vote until TIE ##");
		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		for (int i = 1; i <= 10; i++) {
			service.handle(getVote(i, "YES"));
		}
		for (int i = 11; i <= 20; i++) {
			service.handle(getVote(i, "NO"));
		}

		String handleResult = service.handle(getVote(22, "NO", "VP"));
		System.out.println(handleResult);
		System.out.println("####\n\n");

	}

	@Test
	public void test_auto_close_vp_votes() {
		System.out.println("## Testcase 11 :  Close the poll when VP Votes ##");
		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		for (int i = 1; i <= 10; i++) {
			service.handle(getVote(i, "YES"));
		}
		for (int i = 11; i <= 20; i++) {
			service.handle(getVote(i, "NO"));
		}
		String result = service.closePoll();
		String handleResult = service.handle(getVote(22, "YES", "VP"));
		//System.out.println(result);
		System.out.println(handleResult);
		System.out.println("####\n\n");
	}

	@Test
	public void test_force_close() {
		System.out.println("## Testcase 12 :  Force close if VP not available ##");
		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		for (int i = 1; i <= 10; i++) {
			service.handle(getVote(i, "YES"));
		}
		for (int i = 11; i <= 20; i++) {
			service.handle(getVote(i, "NO"));
		}

		String result = service.closePoll();
		//System.out.println(result);
		String forceResult = service.forceClose();
		System.out.println(forceResult);
		System.out.println("####\n\n");
	}

	@Test
	public void test_force_close_if_not_tie() {
		System.out.println("## Testcase 13 :  Force close not possible if poll is not TIE ##");

		service.setPollData(new PollingData());
		service.setVotes(new HashSet<>());
		service.startPoll();
		for (int i = 1; i <= 10; i++) {
			service.handle(getVote(i, "YES"));
		}
		for (int i = 11; i <= 20; i++) {
			service.handle(getVote(i, "NO"));
		}

		String forceResult = service.forceClose();
		System.out.println(forceResult);
		System.out.println("####\n\n");
	}

	public Vote getVote(int voterId, String preference) {
		return getVote(voterId, preference, "");
	}

	public Vote getVote(int voterId, String preference, String role) {
		Vote vote = new Vote();
		vote.setPreference(preference);

		vote.setRole(role);
		vote.setVotersId(voterId);
		return vote;
	}
}
